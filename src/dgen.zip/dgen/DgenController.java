package dgen;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import dgen.verification.console.TextAreaAppender;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;

public class DgenController implements Initializable{
	@FXML private TableView<Modules> tableview;
	
	@FXML private TableColumn<Modules, String> module;
	
	@FXML private TableColumn<Modules, String> dCount;
	
	@FXML private TableColumn<Modules, Boolean> executionFlagCH;
	
	@FXML private TableColumn<Modules, Boolean> executionFlagUS;
	
	@FXML private TextArea logArea;
	
	@FXML private Button BtnRun;
	
	private ObservableList<Modules> moduleList = FXCollections.observableArrayList();
	
	public static Logger logs = Logger.getLogger(DgenController.class);
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader("./configs/Log4j.properties"));
			Properties loggingProperties = new Properties();
	        
				loggingProperties.load(reader);
				PropertyConfigurator.configure( loggingProperties );
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	        
		getModules();
	    TextAreaAppender.setTextArea(this.logArea);
	    logs.info("DGen Launched...");
	}
	
	private void getModules() {
		this.module.setCellValueFactory(new PropertyValueFactory("moduleName"));
		this.dCount.setCellValueFactory(new PropertyValueFactory("iCount"));
		this.executionFlagCH.setCellValueFactory(new PropertyValueFactory("iCHSelect"));
		this.executionFlagUS.setCellValueFactory(new PropertyValueFactory("iUSSelect"));
		moduleList = getModuleList();
		tableview.setItems(moduleList);
		tableview.setEditable(true);
		this.dCount.setCellFactory(TextFieldTableCell.forTableColumn());
		this.dCount.setOnEditCommit(e -> {
			e.getTableView().getItems().get(e.getTablePosition().getRow()).setiCount(e.getNewValue());
		});
		
	}
	
	private ObservableList<Modules> getModuleList() {
		ObservableList<Modules> list = FXCollections.observableArrayList();
		File folderCH = new File("./resources/InputData/CH");
		File[] listOfFiles = folderCH.listFiles();
		for(File fl:listOfFiles) {
			File folderUS = new File("./resources/InputData/US/"+ fl.getName());
			if(folderUS.exists()) {
				list.add(new Modules(fl.getName().substring(0, fl.getName().indexOf(".")), "", true, true));
			}else {
				list.add(new Modules(fl.getName().substring(0, fl.getName().indexOf(".")), "", true, false));
			}
		}
		return list;
	}
	
	@FXML
	private void Run() {
		ExecutionProcess exec = new ExecutionProcess(moduleList);
		Thread runThread = new Thread(exec);
		runThread.start();
		
	}
	

}
