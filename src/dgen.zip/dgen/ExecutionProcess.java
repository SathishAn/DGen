package dgen;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.Random;
import java.util.Map.Entry;
import javax.net.ssl.*;
import javax.swing.JOptionPane;

import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;
import org.apache.log4j.xml.DOMConfigurator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

import javafx.collections.ObservableList;

public class ExecutionProcess implements Runnable {
	static Fillo fillo = new Fillo();
	private static String User_Agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36";
	public static HashMap<String, String> testData;
	public static HashMap<String, String> result;
	public static HashMap<String, String> cookies;
	public static HashMap<String, String> environData;
	public static HashMap<String, Integer> iteration;
	private final String propertyFilePath = "./configs/config.properties";
	private static String iRegion;
	private static String appUrl;
	private static ObservableList<Modules> moduleList;
	private static String reportPath,reportfile, fileName , logFile;
	private static boolean status;
	private static boolean columnFlag;
	private static Logger logs = Logger.getLogger(ExecutionProcess.class);
	/* Constructor to Load values */  
	public ExecutionProcess(ObservableList<Modules> moduleList) {
		try {
			this.moduleList = moduleList;
			this.logs = DgenController.logs;
			
			environData = new HashMap<>();
			BufferedReader reader = new BufferedReader(new FileReader(propertyFilePath));
			Properties properties = new Properties();
			properties.load(reader);
			for (Entry<Object, Object> prop : properties.entrySet()) {
				environData.put(prop.getKey().toString(), prop.getValue().toString());
			}

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	/*****************************************************************************
	 * 
	 * Launch the Application
	 * 
	 *****************************************************************************/
	public static void loadUrl() {
		try {
			enableSSLSocket();
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cookies = new HashMap<>();
		getService(environData.get("T24"));
	}

	/*****************************************************************************
	 * 
	 * Login with Maker user to the Application
	 * 
	 *****************************************************************************/
	public static void makerLogin() {
		String userName = null, password = null;
		if(iRegion.equals("CH")) {
			userName = environData.get("makerCHUserName");
			password = environData.get("makerCHPassword");
		}else if(iRegion.equals("US")) {
			userName = environData.get("makerUSUserName");
			password = environData.get("makerUSPassword");
		}
		testData = new HashMap<>();
		testData.put("command", "globusCommand");
		testData.put("requestType", "CREATE.SESSION");
		testData.put("signOnName", userName);
		testData.put("password", password);
		loginPostService(environData.get("T24"), testData);
	}

	/*****************************************************************************
	 * 
	 * Login with authorize user to the Application
	 * 
	 *****************************************************************************/
	public static void authorizerLogin() {
		String userName = null, password = null;
		if(iRegion.equals("CH")) {
			userName = environData.get("authoriseCHUser");
			password = environData.get("authoriseCHPassword");
		}else if(iRegion.equals("US")) {
			userName = environData.get("authoriseUSUser");
			password = environData.get("authoriseUSPassword");
		}
		testData = new HashMap<>();
		testData.put("command", "globusCommand");
		testData.put("requestType", "CREATE.SESSION");
		testData.put("signOnName", userName);
		testData.put("password", password);
		loginPostService(environData.get("T24"), testData);
	}

	/*****************************************************************************
	 * 
	 * Create A New Customer
	 * 
	 *****************************************************************************/
	public static String initializeCutomer() {
		String transactionId;
		loadUrl();
		makerLogin();
		extractFormData("InitCustomer");
		Document response = postService(environData.get("T24"), testData);
		Elements TransactionID = response.select("input[id=\"transactionId\"]");
		transactionId = TransactionID.attr("value");
		System.out.println(transactionId);
		return transactionId;
	}

	public static String inputCustomer() {
		String transactionid = initializeCutomer();
		extractExcelData("CustomerCreation", "CustomerCreation");
		testData.put("transactionId", transactionid);
		testData.put("fieldName:NAME.1:1", testData.get("fieldName:NAME.1:1") + testData.get("transactionId"));
		testData.put("fieldName:MNEMONIC", testData.get("fieldName:NAME.1:1").substring(1, 1)
				+ testData.get("fieldName:SHORT.NAME:1").substring(1, 1) + testData.get("transactionId"));
		extractFormData("InputCustomer");
		Document response = postService(environData.get("T24"), testData);
		response = checkAndHandleWarning(response);
		response = checkAndHandleOverRides(response);
		getMessage(response);
		return transactionid;

	}
	
	
	public static void checkErrorExist(Document response) {
			Elements error = response.select("td[class=\"errors\"]");
			if(!error.text().isEmpty()) {
				Elements errorText = response.select("td[class=\"errorText\"]");
				logs.error(errorText.text());
				System.out.println(error.text() + " " + errorText.text());
			
			}
			
	}
	
	

	/*******************************************************************************************
	 * getMessage: To get the final transaction message
	 * 
	 * @param response
	 * 
	 ******************************************************************************************/

	public static String getMessage(Document response) {
		Elements message = response.select("td[class=\"message\"]");
		System.out.println(message.text());
		if(!message.text().isEmpty()) {
			if (!message.text().contains("Txn Complete")) {
				status = false;
			}
			logs.info(message.text());
		}else {
			checkErrorExist(response);
		}
		return message.text();
	}

	/******************************************************************************************
	 * checkAndHandleWarning: Check and handle the warning
	 * 
	 * @param response
	 * @return
	 * 
	 *****************************************************************************************/
	public static Document checkAndHandleWarning(Document response) {
		Elements warning = response.select("input[id=\"warningsPresent\"]");
		if (warning.attr("value").equals("YES")) {
			Elements overRide = response.select("input[id=\"fieldName:OVERRIDE:1\"]");
			testData.put("warningText", overRide.attr("value"));
			response = postService(environData.get("T24"), testData);
		}
		return response;
	}

	/******************************************************************************************
	 * checkAndHandleWarning: Check and handle the OverRides
	 * 
	 * @param response
	 * @return
	 * 
	 *****************************************************************************************/
	public static Document checkAndHandleOverRides(Document response) {
		Elements warning = response.select("input[id=\"OverridesPresent\"]");
		if (warning.attr("value").equals("YES")) {
			Elements overRide = response.select("td[class=\"overrideOn\"]");
			for(Element ov: overRide) {
				logs.warn("OverRides: " + ov.text() );
				testData.put("overrideText:" + ov.text() + ":value", "YES");
			}
			response = postService(environData.get("T24"), testData);
			getMessage(response);
		}
		return response;
	}

	/**************************************************************************************
	 * 
	 * @MethodName authorizeCustomer
	 * 
	 *************************************************************************************/

	public static void authorizeCustomer(String transactionId) {
		loadUrl();
		authorizerLogin();
		extractFormData("AuthCustomer");
		testData.put("transactionId", transactionId);
		Document response = postService(environData.get("T24"), testData);
		getMessage(response);
	}

	/*****************************************************************************
	 * 
	 * Create DDA Account for the Customer
	 * 
	 * @return
	 * 
	 *****************************************************************************/
	public static String intializeAccount() {
		String transactionId;
		loadUrl();
		makerLogin();
		extractFormData("InitAccount");
		Document response = postService(environData.get("T24"), testData);
		Elements TransactionID = response.select("input[id=\"transactionId\"]");
		transactionId = TransactionID.attr("value");
		System.out.println(transactionId);
		return transactionId;
	}

	/****************************************************************************************************
	 * 
	 * Input DDA Cash Account
	 * 
	 ***************************************************************************************************/
	public static String inputAccountCreation(String customerID, String module) {
		String transactionId = intializeAccount();
		if(module.equalsIgnoreCase("DDACashAccount")) {
			extractExcelData("DDACashAccount", "DDACashAccount");
		}else {
			extractExcelData("MoneyMarketAccount", "MoneyMarketAccount");
		}
		testData.put("transactionId", transactionId);
		testData.put("fieldName:CUSTOMER", customerID);
		extractFormData("InputAccount");
		Document response = postService(environData.get("T24"), testData);
		getMessage(response);
		return transactionId;
	}
	/****************************************************************************************************
	 * 
	 * Input AUM DDA Cash Account
	 * 
	 ***************************************************************************************************/	
	public static String inputAccountCreation() {
		String transactionId = intializeAccount();
		extractFormData("InputAccount");
		extractExcelData("AUM_Account", "AUM_Account");
		testData.put("transactionId", transactionId);
		System.out.println(testData.get("fieldName:CUSTOMER"));
		Document response = postService(environData.get("T24"), testData);
		getMessage(response);
		return transactionId;
	}
	
	/****************************************************************************************************
	 * 
	 * Authorize Account
	 * 
	 ***************************************************************************************************/
	public static void authAccount(String accountID) {
		loadUrl();
		authorizerLogin();
		extractFormData("AuthAccount");
		testData.put("transactionId", accountID);
		Document response = postService(environData.get("T24"), testData);
		getMessage(response);
	}
	
	/****************************************************************************************************
	 * 
	 * Customer Charge
	 * 
	 ***************************************************************************************************/
	public static void customerCharge(String customerID) {
		loadUrl();
		makerLogin();
		extractFormData("CustomerCharge");
		testData.put("transactionId", customerID);
		testData.put("fieldName:DEPOSITORY.GROUP", "999");
		Document response = postService(environData.get("T24"), testData);
		getMessage(response);
	}
	
	/****************************************************************************************************
	 * 
	 * Customer Security
	 * 
	 ***************************************************************************************************/
	public static void customerSecurity(String customerID, String module) {
		loadUrl();
		makerLogin();
		extractFormData("CustomerSecurity");
		if(module.equalsIgnoreCase("CustomerSecurity")) {
			extractExcelData("CustomerSecurity", "CustomerPortFolio");
		}else if(module.equalsIgnoreCase("Broker")) {
			extractExcelData("Broker", "Broker");
		}else if(module.equalsIgnoreCase("Depository")) {
			extractExcelData("Depository", "Depository");
		}
		testData.put("transactionId", customerID);
		Document response = postService(environData.get("T24"), testData);
		getMessage(response);
	}
	/****************************************************************************************************
	 * 
	 * Customer AUM Security
	 * 
	 ***************************************************************************************************/
	public static void customerSecurity() {
		loadUrl();
		makerLogin();
		extractFormData("CustomerSecurity");
		extractExcelData("CustomerSecurity", "AUM_CustomerPortFolio");
		Document response = postService(environData.get("T24"), testData);
		getMessage(response);
	}
	
	

	public static String createCustomerPortFolio(String customerID, String AccountNo) {
		String portfolioId = customerID + "-1";
		loadUrl();
		makerLogin();
		extractFormData("CustomerPortFolio");
		extractExcelData("CustomerPortFolio", "CustomerPortFolio");
		testData.put("transactionId", customerID);
		testData.put("fieldName:CUSTOMER.NUMBER", customerID);
		testData.put("fieldName:ACCOUNT.NOS:1", AccountNo);
		Document response = postService(environData.get("T24"), testData);
		checkAndHandleOverRides(response);
		getMessage(response);
		return portfolioId;
	}
	
	public static String createCustomerPortFolio() {
		loadUrl();
		makerLogin();
		extractFormData("CustomerPortFolio");
		extractExcelData("AUM_CustomerPortFolio", "AUM_CustomerPortFolio");
		String portfolioId = testData.get("transactionId") ;
		Document response = postService(environData.get("T24"), testData);
		checkAndHandleOverRides(response);
		getMessage(response);
		return portfolioId;

	}
	

	public static void createFeesTestData(String customerID, String AccountNo) {
		String portfolioId = customerID + "-1";
		loadUrl();
		makerLogin();
		extractFormData("FeesData");
		extractExcelData("FeesData", "FeesData");
		testData.put("transactionId", customerID);
		testData.put("fieldName:CUSTOMER.NUMBER", customerID);
		testData.put("fieldName:ACCOUNT.NOS:1", AccountNo);
		Document response = postService(environData.get("T24"), testData);
		checkAndHandleOverRides(response);
		getMessage(response);

	}
	
	/*****************************************************************************
	 * 
	 * Initialize A New counter party customer
	 * 
	 *****************************************************************************/
	public static String initializeCounterPartyCutomer() {
		String transactionId;
		loadUrl();
		makerLogin();
		extractFormData("InitCounterParty");
		Document response = postService(environData.get("T24"), testData);
		Elements TransactionID = response.select("input[id=\"transactionId\"]");
		transactionId = TransactionID.attr("value");
		System.out.println(transactionId);
		return transactionId;
	}
	/*****************************************************************************
	 * 
	 * Input counter party customer
	 * 
	 *****************************************************************************/
	public static String inputCounterPartyCutomer() {
		String transactionId = initializeCounterPartyCutomer();
		extractFormData("InputCounterParty");
		extractExcelData("CounterParty", "CounterParty");
		testData.put("transactionId", transactionId);
		testData.put("fieldName:NAME.1:1", testData.get("fieldName:NAME.1:1") + transactionId);
		testData.put("fieldName:MNEMONIC", testData.get("fieldName:NAME.1:1").substring(1, 1)
				+ testData.get("fieldName:SHORT.NAME:1").substring(1, 1) + transactionId);
		Document response = postService(environData.get("T24"), testData);
		checkAndHandleOverRides(response);
		getMessage(response);
		return transactionId;
	}
	
	/*****************************************************************************
	 * 
	 * Authorize counter party customer
	 * 
	 *****************************************************************************/
	public static void authorizeCounterPartyCustomer(String transactionId) {
		loadUrl();
		authorizerLogin();
		extractFormData("AuthCounterParty");
		testData.put("transactionId", transactionId);
		Document response = postService(environData.get("T24"), testData);
		getMessage(response);
	}
	
	
	/*****************************************************************************
	 * 
	 * Initialize Nastro Account
	 * 
	 *****************************************************************************/
	public static String intializeNastroAccount() {
		String transactionId;
		loadUrl();
		makerLogin();
		extractFormData("InitNastroAccount");
		Document response = postService(environData.get("T24"), testData);
		Elements TransactionID = response.select("input[id=\"transactionId\"]");
		transactionId = TransactionID.attr("value");
		System.out.println(transactionId);
		return transactionId;
	}
	
	/*****************************************************************************
	 * 
	 * Create Nastro Account
	 * 
	 *****************************************************************************/
	
	public static String createNastroAccount(String customerID) {
		String transactionId = intializeAccount();
		extractFormData("InputNastroAccount");
		extractExcelData("NastroAccount", "NastroAccount");
		testData.put("transactionId", transactionId);
		testData.put("fieldName:CUSTOMER", customerID);
		Document response = postService(environData.get("T24"), testData);
		try {
			BufferedWriter fos = new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(new File("./response.html"))));
			fos.write(response.html());
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		getMessage(response);
		return transactionId;
	}

	/*****************************************************************************
	 * 
	 * Authorise Nastro Account
	 * 
	 *****************************************************************************/
	public static void authoriseNastroAccount(String accountID) {
		loadUrl();
		authorizerLogin();
		extractFormData("AuthNastroAccount");
		testData.put("transactionId", accountID);
		Document response = postService(environData.get("T24"), testData);
		getMessage(response);
	}

	
	/*****************************************************************************
	 * 
	 * Initialize Fund Transfer
	 * @return 
	 * 
	 *****************************************************************************/
	public static String initializeFundTransfer() {
		String transactionId;
		loadUrl();
		makerLogin();
		extractFormData("InitFundTransfer");
		Document response = postService(environData.get("T24"), testData);
		Elements TransactionID = response.select("input[id=\"transactionId\"]");
		transactionId = TransactionID.attr("value");
		System.out.println(transactionId);
		return transactionId;
	}
	
	/*****************************************************************************
	 * 
	 * Input Fund Transfer
	 * @return 
	 * 
	 *****************************************************************************/
	public static String inputFundTransfer(String accountId) {
		String transactionId = initializeFundTransfer();
		extractFormData("InputFundTransfer");
		extractExcelData("FundTransfer", "FundTransfer");
		testData.put("transactionId", transactionId);
		testData.put("fieldName:CREDIT.ACCT.NO", accountId);
		Document response = postService(environData.get("T24"), testData);
		response= checkAndHandleOverRides(response);
		getMessage(response);
		return transactionId;
	}
	/*****************************************************************************
	 * 
	 * Input AUM Fund Transfer
	 * @return 
	 * 
	 *****************************************************************************/
	public static String inputFundTransfer() {
		String transactionId = initializeFundTransfer();
		extractFormData("InputFundTransfer");
		extractExcelData("AUM_FundTransfer", "AUM_FundTransfer");
		testData.put("transactionId", transactionId);
		Document response = postService(environData.get("T24"), testData);
		response= checkAndHandleOverRides(response);
		getMessage(response);
		return transactionId;
	}
	
	
	/*****************************************************************************
	 * 
	 * Authorise Fund Transfer
	 * @return 
	 * 
	 *****************************************************************************/
	public static void authoriseFundTransfer(String fundTransferId) {
		loadUrl();
		authorizerLogin();
		extractFormData("AuthFundTransfer");
		testData.put("transactionId", fundTransferId);
		Document response = postService(environData.get("T24"), testData);
		getMessage(response);
	}
	/*****************************************************************************
	 * 
	 * Initialize Securities
	 * @return 
	 * 
	 *****************************************************************************/
	public static String initializeEquity() {
		String transactionId;
		loadUrl();
		makerLogin();
		extractFormData("InitEquity");
		Document response = postService(environData.get("T24"), testData);
		Elements TransactionID = response.select("input[id=\"transactionId\"]");
		transactionId = TransactionID.attr("value");
		System.out.println(transactionId);
		return transactionId;
	}
	
	/*****************************************************************************
	 * 
	 * Input Securities
	 * @return 
	 * 
	 *****************************************************************************/
	public static String inputEquity() {
		String transactionId = initializeEquity();
		extractFormData("InputEquity");
		extractExcelData("Equity", "Equity");
		String companyName = testData.get("fieldName:COMPANY.NAME:1") + transactionId.substring(transactionId.indexOf("-")+1);
		String shortName= testData.get("fieldName:SHORT.NAME:1") + transactionId.substring(transactionId.indexOf("-")+1);
		String Mnemonic= companyName.substring(0,1)+ shortName.substring(0,1)+ transactionId.substring(transactionId.indexOf("-")+1);
		System.out.println(Mnemonic);
		testData.put("fieldName:COMPANY.NAME:1", companyName);
		testData.put("fieldName:SHORT.NAME:1", shortName);
		testData.put("fieldName:MNEMONIC", Mnemonic);
		testData.put("transactionId", transactionId);
		Document response = postService(environData.get("T24"), testData);
		response= checkAndHandleOverRides(response);
		getMessage(response);
		return transactionId;
	}
	
	/*****************************************************************************
	 * 
	 * Authorise Securities
	 * @return 
	 * 
	 *****************************************************************************/
	public static void authoriseEquity(String securityId) {
		loadUrl();
		authorizerLogin();
		extractFormData("AuthEquity");
		testData.put("transactionId", securityId);
		Document response = postService(environData.get("T24"), testData);
		getMessage(response);
	}
	
	/*****************************************************************************
	 * 
	 * Initialize BuyOrder
	 * @return 
	 * 
	 *****************************************************************************/
	public static String initializeEquityBuyOrder() {
		String transactionId;
		loadUrl();
		makerLogin();
		extractFormData("InitEquityBuyOrder");
		Document response = postService(environData.get("T24"), testData);
		Elements TransactionID = response.select("input[id=\"transactionId\"]");
		transactionId = TransactionID.attr("value");
		System.out.println(transactionId);
		return transactionId;
	}
	
	/*****************************************************************************
	 * 
	 * Input Buy Order
	 * @return 
	 * 
	 *****************************************************************************/
	public static String inputEquityBuyOrder(String equiteeID, String customerID, String Depository) {
		String transactionId = initializeEquityBuyOrder();
		extractFormData("InputEquityBuyOrder");
		extractExcelData("BuyOrder", "EquityBuyOrder");
		testData.put("transactionId", transactionId);
		testData.put("fieldName:SECURITY.NO", equiteeID);
		testData.put("fieldName:CUST.NUMBER:1", customerID);
		testData.put("fieldName:SECURITY.ACCNT:1", customerID+"-1");
		testData.put("fieldName:DEPOSITORY", Depository);
		Document response = postService(environData.get("T24"), testData);
		response= checkAndHandleOverRides(response);
		getMessage(response);
		return transactionId;
	}
	
	/*****************************************************************************
	 * 
	 * Initialize Equity SellOrder
	 * @return 
	 * 
	 *****************************************************************************/
	public static String initializeEquitySellOrder() {
		String transactionId;
		loadUrl();
		makerLogin();
		extractFormData("InitEquitySellOrder");
		Document response = postService(environData.get("T24"), testData);
		Elements TransactionID = response.select("input[id=\"transactionId\"]");
		transactionId = TransactionID.attr("value");
		System.out.println(transactionId);
		return transactionId;
	}
	
	/*****************************************************************************
	 * 
	 * Input Equity Sell Order
	 * @return 
	 * 
	 *****************************************************************************/
	public static String inputEquitySellOrder(String equiteeID, String customerID, String Depository) {
		String transactionId = initializeEquitySellOrder();
		extractFormData("InputEquitySellOrder");
		extractExcelData("SellOrder", "EquitySellOrder");
		testData.put("transactionId", transactionId);
		testData.put("fieldName:SECURITY.NO", equiteeID);
		testData.put("fieldName:CUST.NUMBER:1", customerID);
		testData.put("fieldName:SECURITY.ACCNT:1", customerID+"-1");
		testData.put("fieldName:DEPOSITORY", Depository);
		Document response = postService(environData.get("T24"), testData);
		response= checkAndHandleOverRides(response);
		getMessage(response);
		return transactionId;
	}
	
	
	/*****************************************************************************
	 * 
	 * Input Order Transmit
	 * @return 
	 * 
	 *****************************************************************************/
	public static String inputOrderTransmit(String orderType,String transactionId) {
		extractFormData("InputOrderTransmit");
		if(orderType.equalsIgnoreCase("BUY")) {
			extractExcelData("OrderTransmit", "EquityBuyOrder");
		}else {
			extractExcelData("OrderTransmit", "EquitySellOrder");
		}
		
		testData.put("transactionId", transactionId);
		/*testData.put("fieldName:CUST.NUMBER:1", customerID);
		testData.put("fieldName:SECURITY.ACCNT:1", customerID+"-1");
		testData.put("fieldName:DEPOSITORY", Depository);*/
		Document response = postService(environData.get("T24"), testData);
		response= checkAndHandleOverRides(response);
		getMessage(response);
		return transactionId;
	}
	
	/*****************************************************************************
	 * 
	 * Input Order Transmit
	 * @return 
	 * 
	 *****************************************************************************/
	public static String inputDealerBlotter(String orderType, String BrokerID, String transactionId) {
		loadUrl();
		makerLogin();
		extractFormData("InputDealerBlotter");
		if(orderType.equalsIgnoreCase("BUY")) {
			extractExcelData("DealerBlotter", "EquityBuyOrder");
		}else {
			extractExcelData("DealerBlotter", "EquitySellOrder");
		}
		
		testData.put("transactionId", transactionId);
		testData.put("fieldName:BROKER.NO:1", BrokerID);
		Document response = postService(environData.get("T24"), testData);
		response= checkAndHandleOverRides(response);
		try {
			BufferedWriter fos = new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(new File("./test.html"))));
			fos.write(response.html());
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		getMessage(response);
		return transactionId;
	}
	
	
	/*****************************************************************************
	 * 
	 * Authorise Equity Transaction
	 * @return 
	 * 
	 *****************************************************************************/
	public static String authSecurityTransaction(String orderType, String BrokerID, String transactionId) {
		String secTransId = null;
		loadUrl();
		authorizerLogin();
		extractFormData("EnquireSecurityTrade");
		testData.put("transactionId", transactionId);
		Document response = postService(environData.get("T24"), testData);
		 Elements TransId =  response.select("span");
		 for(Element tran:TransId) {
			 if(tran.text().contains("SCTRSC")) {
				 secTransId = tran.text();
				 break;
			 }
		 }
		
		System.out.println(secTransId);
		extractFormData("AuthEquityTransaction");
		if(orderType.equalsIgnoreCase("BUY")) {
			extractExcelData("AuthoriseEquityOrder", "EquityBuyOrder");
			testData.put("fieldName:BR.BEN.BANK.1:1", BrokerID);
		}else {
			extractExcelData("AuthoriseEquityOrder", "EquitySellOrder");
		}
		testData.put("transactionId", secTransId);
		response = postService(environData.get("T24"), testData);
		response= checkAndHandleOverRides(response);
		try {
			BufferedWriter fos = new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(new File("./test.html"))));
			fos.write(response.html());
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		getMessage(response);
		return transactionId;
	}
	
	/*
	 * public static void inputArrangementAccountCreation(String customerID) {
	 * String transactionId = intializeAccount();
	 * extractExcelData("AccountCreation_1", "AccountCreation");
	 * extractExcelData("ValidateAccount");
	 * testData.put("transactionId", transactionId);
	 * testData.put("fieldName:CUSTOMER:1", customerID); Document response =
	 * postService(environData.get("T24"), testData); Elements user =
	 * response.select("input[id=\"user\"]"); String userId = user.attr("value");
	 * System.out.println(user.attr("value")); Elements arrangementId =
	 * response.select("input[id=\"fieldName:ARRANGEMENT\"]"); String aggrementID =
	 * arrangementId.attr("value"); System.out.println(aggrementID); Elements accID
	 * = response.select("input[id=\"fieldName:ACCOUNT.REFERENCE\"]"); String
	 * accountID = accID.attr("value");
	 * 
	 * 
	 * 
	 * 
	 * System.out.println(accountID); extractExcelData("CommitAccount",
	 * "UserInput");
	 * 
	 * extractArrangementData("Arrangement", aggrementID);
	 * testData.put("appreq:transactionId", transactionId);
	 * testData.put("appreq:fieldName:ARRANGEMENT", aggrementID);
	 * testData.put("appreq:fieldName:CUSTOMER:1", customerID);
	 * testData.put("AA.ARR.CUSTOMER,ITAU.AA"+aggrementID+
	 * "-CUSTOMER-20190122.1:fieldName:CUSTOMER:1", customerID);
	 * testData.put("AA.ARR.ACCOUNT,ITAU.AA.AR"+aggrementID+
	 * "-BALANCE-20190122.1:fieldName:ACCOUNT.REFERENCE", accountID);
	 * testData.put("AA.ARR.CUSTOMER,ITAU.AA"+aggrementID+
	 * "-CUSTOMER-20190122.1:user", userId);
	 * testData.put("AA.ARR.OFFICERS,ITAU.AA"+aggrementID+
	 * "-OFFICERS-20190122.1:user", userId);
	 * testData.put("AA.ARR.LIMIT,ITAU.AA.REF"+aggrementID+"-LIMIT-20190122.1:user",
	 * userId); testData.put("AA.ARR.BALANCE.AVAILABILITY,ITAU.AA"+aggrementID+
	 * "-BALANCE.AVAILABILITY-20190122.1:user", userId);
	 * testData.put("AA.ARR.CLOSURE,ITAU.AA"+aggrementID+"-CLOSURE-20190122.1:user",
	 * userId); testData.put("AA.ARR.ACCOUNT,ITAU.AA.AR"+aggrementID+
	 * "-BALANCE-20190122.1:user", userId);
	 * testData.put("AA.ARR.INTEREST,AA"+aggrementID+"-DRINTEREST-20190122.1:user",
	 * userId); testData.put("AA.ARR.PAYMENT.SCHEDULE,AA"+aggrementID+
	 * "-SCHEDULE-20190122.1:user", userId);
	 * testData.put("AA.ARR.SETTLEMENT,AA.NOINPUT"+aggrementID+
	 * "-SETTLEMENT-20190122.1:user", userId);
	 * testData.put("AA.ARR.BALANCE.MAINTENANCE,AA.NOINPUT"+aggrementID+
	 * "-BALANCE.MAINTENANCE-20190122.1:user", userId);
	 * testData.put("AA.ARR.PAYOFF,AA"+aggrementID+"-PAYOFF-20190122.1:user",
	 * userId); response = postService(environData.get("T24"), testData);
	 * getMessage(response); try { BufferedWriter fos = new BufferedWriter(new
	 * OutputStreamWriter(new FileOutputStream( new File("./response.html"))));
	 * fos.write(response.html()); fos.close(); } catch (IOException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); }
	 * 
	 * 
	 * }
	 */

	/**********************************************************************************************
	 * 
	 * TestCases of customer Creation
	 * 
	 **********************************************************************************************/

	public static void customerCreation(int iCount) {
		String module = "CustomerCreation", iStatus;
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = {"ScenarioName", "CustomerNumber",  "Status" };
		createHeaders(module, colName);
		String transactionId = inputCustomer();
		authorizeCustomer(transactionId);
		result.put("ScenarioName", module + iCount);
		result.put("CustomerNumber", transactionId);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);

	}

	/**********************************************************************************************
	 * 
	 * TestCases of DDA Cash Account Creation
	 * 
	 **********************************************************************************************/
	public static void createDDACashAccount(int iCount) {
		String customerID, accountID;
		String module = "DDACashAccount";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = { "CustomerNumber", "AccountNumber",  "Status" };
		createHeaders(module, colName);
		customerID = inputCustomer();
		authorizeCustomer(customerID);
		accountID = inputAccountCreation(customerID, module);
		authAccount(accountID);
		result.put("ScenarioName", module + iCount);
		result.put("CustomerNumber", customerID);
		result.put("AccountNumber", accountID);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);
	}
	
	/**********************************************************************************************
	 * 
	 * TestCases of create MoneyMarket Account Account Creation
	 * 
	 **********************************************************************************************/
	public static void createMoneyMarketAccount(int iCount) {
		String customerID, accountID;
		String module = "MoneyMarketAccount";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = { "CustomerNumber", "AccountNumber",  "Status" };
		createHeaders(module, colName);
		customerID = inputCustomer();
		authorizeCustomer(customerID);
		accountID = inputAccountCreation(customerID, module);
		authAccount(accountID);
		result.put("ScenarioName", module + iCount);
		result.put("CustomerNumber", customerID);
		result.put("AccountNumber", accountID);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);
	}

	/**********************************************************************************************
	 * 
	 * TestCases of Customer Portfolio Creation
	 * 
	 **********************************************************************************************/
	public static void customerPortFolio( int iCount) {
		String customerID, accountID, portfolioId;
		String module = "CustomerPortfolio";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = { "CustomerNumber", "AccountNumber", "CustomerPortfolio",  "Status" };
		createHeaders(module, colName);
		customerID = inputCustomer();
		authorizeCustomer(customerID);
		accountID = inputAccountCreation(customerID, "DDACashAccount");
		authAccount(accountID);
		customerSecurity(customerID, "CustomerSecurity");
		portfolioId = createCustomerPortFolio(customerID, accountID);
		result.put("ScenarioName", module + iCount);
		result.put("CustomerNumber", customerID);
		result.put("AccountNumber", accountID);
		result.put("CustomerPortfolio", portfolioId);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);

	}
	/**********************************************************************************************
	 * 
	 * TestCases of Broker creation
	 * 
	 **********************************************************************************************/
	public static void createBroker(int iCount) {
		String customerID, accountID, portfolioId;
		String module = "Broker";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = {"CustomerNumber",  "Status" };
		createHeaders(module, colName);
		customerID = inputCustomer();
		authorizeCustomer(customerID);
		customerSecurity(customerID, module);
		result.put("ScenarioName", module + iCount);
		result.put("CustomerNumber", customerID);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);

	}
	
	/**********************************************************************************************
	 * 
	 * TestCases of Depository creation
	 * 
	 **********************************************************************************************/
	public static void createDepository(int iCount) {
		String customerID, accountID, portfolioId;
		String module = "Depository";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = {"CustomerNumber",  "Status" };
		createHeaders(module, colName);
		customerID = inputCustomer();
		authorizeCustomer(customerID);
		customerCharge(customerID);
		customerSecurity(customerID, module);
		result.put("ScenarioName", module + iCount);
		result.put("CustomerNumber", customerID);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);

	}

	/**********************************************************************************************
	 * 
	 * TestCases of Customer Portfolio Creation
	 * 
	 **********************************************************************************************/
	public static void feesTestData(int iCount) {
		String customerID, accountID, portfolioId;
		String module = "FeesData";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = { "CustomerNumber", "AccountNumber", "CustomerPortfolio",  "Status" };
		createHeaders(module, colName);
		customerID = inputCustomer();
		authorizeCustomer(customerID);
		accountID = inputAccountCreation(customerID, "DDACashAccount");
		authAccount(accountID);
		customerSecurity(customerID, "CustomerSecurity");
		portfolioId = createCustomerPortFolio(customerID, accountID);
		createFeesTestData(customerID, accountID);
		result.put("ScenarioName", module + iCount);
		result.put("CustomerNumber", customerID);
		result.put("AccountNumber", accountID);
		result.put("CustomerPortfolio", portfolioId);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);

	}
	
	/**********************************************************************************************
	 * 
	 * TestCases of FundTransfer
	 * 
	 **********************************************************************************************/
	public static void fundTransfer(int iCount) {
		String customerID, accountID, portfolioId, fundTransferId;
		String module = "FundTransfer";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = { "CustomerNumber", "AccountNumber", "CustomerPortfolio", "FundTransferID",  "Status" };
		createHeaders(module, colName);
		customerID = inputCustomer();
		authorizeCustomer(customerID);
		accountID = inputAccountCreation(customerID, "DDACashAccount");
		authAccount(accountID);
		customerSecurity(customerID, "CustomerSecurity");
		portfolioId = createCustomerPortFolio(customerID, accountID);
		fundTransferId = inputFundTransfer(accountID);
		authoriseFundTransfer(fundTransferId);
		result.put("ScenarioName", module + iCount);
		result.put("CustomerNumber", customerID);
		result.put("AccountNumber", accountID);
		result.put("CustomerPortfolio", portfolioId);
		result.put("FundTransferID", fundTransferId);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);
	}
	
	
	

	/**************************************************************************************
	 * 
	 * TestCases of CounterParty Customer Creation
	 * 
	 *************************************************************************************/
	public static void  counterPartyCreation(int iCount) {
		String customerId;
		String module = "CounterParty";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = {"CustomerNumber",  "Status" };
		createHeaders(module, colName);
		String transactionId = inputCounterPartyCutomer();
		authorizeCounterPartyCustomer(transactionId);
		result.put("ScenarioName", module + iCount);
		result.put("CustomerNumber", transactionId);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);
		
	}
	
	/**************************************************************************************
	 * 
	 * TestCases of Nastro Account
	 * 
	 *************************************************************************************/
	public static void createNastroAccount(int iCount) {
		String customerID, accountID;
		String module = "NastroAccount";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = { "CustomerNumber", "AccountNumber",  "Status" };
		createHeaders(module, colName);
		customerID = inputCounterPartyCutomer();
		authorizeCounterPartyCustomer(customerID);
		accountID = createNastroAccount(customerID);
		authoriseNastroAccount(accountID);
		result.put("ScenarioName", module + iCount);
		result.put("CustomerNumber", customerID);
		result.put("AccountNumber", accountID);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);
		
	}
	
	/**************************************************************************************
	 * 
	 * TestCases of Equity
	 * 
	 *************************************************************************************/
	public static void createEquity(int iCount) {
		String equityId;
		String module = "Equity";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = { "EquityId", "Status" };
		equityId = inputEquity();
		authoriseEquity(equityId);
		result.put("ScenarioName", module + iCount);
		result.put("EquityId", equityId);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);
		
	}
	
	/**************************************************************************************
	 * 
	 * TestCases of Equity Buy Order
	 * 
	 *************************************************************************************/
	public static void createEquityBuyOrder(int iCount) {
		String secuirtyCustomer, depositoryCustomer, brokerCustomer , accountID, portfolioId, equityId, buyId;
		String module = "EquityBuyOrder";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = { "CustomerNumber", "AccountNumber", "DepositoryCustomer", "BrokerCustomer", "PortFolioID", "EquityID", "BuyOrderID", "TradeID", "Status" };
		createHeaders(module, colName);
		secuirtyCustomer = inputCustomer();
		authorizeCustomer(secuirtyCustomer);
		accountID = inputAccountCreation(secuirtyCustomer, "DDACashAccount");
		authAccount(accountID);
		customerSecurity(secuirtyCustomer, "CustomerSecurity");
		portfolioId = createCustomerPortFolio(secuirtyCustomer, accountID);
		depositoryCustomer = inputCustomer();
		authorizeCustomer(depositoryCustomer);
		customerCharge(depositoryCustomer);
		customerSecurity(depositoryCustomer, "Depository");
		brokerCustomer = inputCustomer();
		authorizeCustomer(brokerCustomer);
		customerSecurity(brokerCustomer, "BROKER");
		equityId = inputEquity();
		authoriseEquity(equityId);
		buyId = inputEquityBuyOrder(equityId, secuirtyCustomer, depositoryCustomer);
		inputOrderTransmit("BUY",buyId);
		inputDealerBlotter("BUY", brokerCustomer, buyId);	
		authSecurityTransaction("BUY", brokerCustomer, buyId);
		result.put("ScenarioName", module + iCount);
		result.put("CustomerNumber", secuirtyCustomer);
		result.put("PortFolioID", portfolioId);
		result.put("DepositoryCustomer", depositoryCustomer);
		result.put("BrokerCustomer", brokerCustomer);
		result.put("EquityId", equityId);
		result.put("BuyOrderID", buyId);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);
	}
	
	
	/**************************************************************************************
	 * 
	 * TestCases of Equity Buy Order and Sell Order
	 * 
	 *************************************************************************************/
	public static void createEquityBuySellOrder(int iCount) {
		String secuirtyCustomer, depositoryCustomer, brokerCustomer , accountID, portfolioId, equityId, buyId, sellId;
		String module = "EquityBuyOrder";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = { "CustomerNumber", "AccountNumber", "DepositoryCustomer", "BrokerCustomer", "PortFolioID", "EquityID", "BuyOrderID", "TradeID", "SellOrderID", "Status" };
		createHeaders(module, colName);
		secuirtyCustomer = inputCustomer();
		authorizeCustomer(secuirtyCustomer);
		accountID = inputAccountCreation(secuirtyCustomer, "DDACashAccount");
		authAccount(accountID);
		customerSecurity(secuirtyCustomer, "CustomerSecurity");
		portfolioId = createCustomerPortFolio(secuirtyCustomer, accountID);
		depositoryCustomer = inputCustomer();
		authorizeCustomer(depositoryCustomer);
		customerCharge(depositoryCustomer);
		customerSecurity(depositoryCustomer, "Depository");
		brokerCustomer = inputCustomer();
		authorizeCustomer(brokerCustomer);
		customerSecurity(brokerCustomer, "BROKER");
		equityId = inputEquity();
		authoriseEquity(equityId);
		buyId = inputEquityBuyOrder(equityId, secuirtyCustomer, depositoryCustomer);
		inputOrderTransmit("BUY",buyId);
		inputDealerBlotter("BUY", brokerCustomer, buyId);	
		authSecurityTransaction("BUY", brokerCustomer, buyId);
		System.out.println("BuyOrder Completed");
		sellId = inputEquitySellOrder(equityId, secuirtyCustomer, depositoryCustomer);
		inputOrderTransmit("SELL",sellId);
		inputDealerBlotter("SELL", brokerCustomer, sellId);	
		authSecurityTransaction("SELL", brokerCustomer, sellId);
		result.put("ScenarioName", module + iCount);
		result.put("CustomerNumber", secuirtyCustomer);
		result.put("PortFolioID", portfolioId);
		result.put("DepositoryCustomer", depositoryCustomer);
		result.put("BrokerCustomer", brokerCustomer);
		result.put("EquityId", equityId);
		result.put("BuyOrderID", buyId);
		result.put("SellOrderID", sellId);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);
	}
	
	/**************************************************************************************
	 * 
	 * TestCases of AUM Accounts
	 * 
	 *************************************************************************************/
	
	public static void createAUMAccount(int iCount) {
		String accountID;
		String module = "AUM_Account";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = { "AccountNumber",  "Status" };
		createHeaders(module, colName);
		accountID = inputAccountCreation();
		authAccount(accountID);
		result.put("ScenarioName", module + iCount);
		result.put("AccountNumber", accountID);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);
	}
	
	/**************************************************************************************
	 * 
	 * TestCases of AUM Portfolio
	 * 
	 *************************************************************************************/
	
	public static void createAUMPortfolio(int iCount) {
		String portfolioId;
		String module = "AUM_Portfolio";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = {"CustomerPortfolio",  "Status" };
		createHeaders(module, colName);
		customerSecurity();
		portfolioId = createCustomerPortFolio();
		result.put("ScenarioName", module + iCount);
		result.put("CustomerPortfolio", portfolioId);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);
	}
	
	/**************************************************************************************
	 * 
	 * TestCases of AUM FundTransfer
	 * 
	 *************************************************************************************/
	public static void createAUMFundTransfer(int iCount) {
		String fundTransferId;
		String module = "AUM_FundTransfer";
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = {"FundTransferID",  "Status" };
		createHeaders(module, colName);
		fundTransferId = inputFundTransfer();
		authoriseFundTransfer(fundTransferId);
		result.put("FundTransferID", fundTransferId);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
	}
	
	
	public static void getService(String iURl) {

		try {
			Connection.Response appUrl = Jsoup.connect(iURl).method(Connection.Method.GET).userAgent(User_Agent)
					.execute();

			cookies.putAll(appUrl.cookies());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void loginPostService(String iUrl, HashMap<String, String> formData) {
		try {
			Connection.Response loginForm = Jsoup.connect(iUrl).cookies(cookies).data(formData)
					.method(Connection.Method.POST).userAgent(User_Agent).execute();
			cookies.clear();

			cookies.putAll(loginForm.cookies());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static Document postService(String iUrl, HashMap<String, String> formData) {
		Document responseText = null;
		try {
			Connection.Response serviceUrl = Jsoup.connect(iUrl).cookies(cookies).data(formData)
					.method(Connection.Method.POST).userAgent(User_Agent).timeout(15000).execute();

			responseText = serviceUrl.parse();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return responseText;

	}

	public static HashMap<String, String> extractFormData(String ScenarioName) {
		com.codoid.products.fillo.Connection connection = null;
		String sheetName = null;
		if(iRegion.equals("CH")) {
			sheetName = "CH";
		}else {
			sheetName = "US";
		}
		Recordset recordset = null;
		try {
			connection = fillo.getConnection("./resources/DGenInput.xlsx");
			String strQuery = "Select * from " + sheetName + " where ScenarioName='" + ScenarioName + "'";
			recordset = connection.executeQuery(strQuery);
			while (recordset.next()) {
				ArrayList<String> ColCollection = recordset.getFieldNames();
				int iCount;
				int size = ColCollection.size();
				for (int Iter = 0; Iter <= (size - 1); Iter++) {

					String ColName = ColCollection.get(Iter);
					String ColValue = recordset.getField(ColName);
					if (!ColName.equalsIgnoreCase("ScenarioName")) {
						if (!ColValue.isEmpty()) {
							testData.put(ColName, ColValue);
						}

					}

				}
			}

		} catch (FilloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			recordset.close();
			connection.close();
		}

		return testData;
	}

	public static HashMap<String, String> extractExcelData(String sheetname, String module) {
		com.codoid.products.fillo.Connection connection = null;
		Recordset recordset = null;
		int iRecordCount, i = 1;
		try {
			connection = fillo.getConnection("./resources/InputData/" + iRegion + "/"+ module +".xlsx");
			String strQuery = "Select * from " + sheetname + " where ExecutionFlag='Y'";
			recordset = connection.executeQuery(strQuery);
			iRecordCount = recordset.getCount();
			if(!iteration.containsKey(sheetname)) {
				iteration.put(sheetname, 1);
			}
			
			
			if(iteration.get(sheetname) <= iRecordCount) {
				//iteration++;
			}else {
				iteration.put(sheetname, 1);
			}
			while (recordset.next()) {
				int svalue = iteration.get(sheetname);
				if(i == iteration.get(sheetname)) {
					ArrayList<String> ColCollection = recordset.getFieldNames();
					int iter;
					int size = ColCollection.size();
					for (iter = 0; iter <= (size - 1); iter++) {
	
						String ColName = ColCollection.get(iter);
						String ColValue = recordset.getField(ColName);
						if (!ColName.equalsIgnoreCase("ScenarioName")) {
							if (!ColValue.isEmpty()) {
								testData.put(ColName, ColValue);
							}
	
						}
						
					}
					svalue++;
					iteration.put(sheetname, svalue);					
					break;
					}else {
						i++;
					}
					
			}

		} catch (FilloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			recordset.close();
			connection.close();
		}
 
		return testData;
	}

	public static void updateTestData(String Sheetname, HashMap<String, String> result) {
		com.codoid.products.fillo.Connection connection = null;
		try {
			connection = fillo.getConnection(reportfile);
			StringBuffer setKey = new StringBuffer();
			StringBuffer setValue = new StringBuffer();
			for (Entry<String, String> rst : result.entrySet()) {
				if (setKey.toString().isEmpty()) {
					setKey.append("(" + rst.getKey());
				} else {
					setKey.append("," + rst.getKey());
				}

				if (setValue.toString().isEmpty()) {
					setValue.append("('" + rst.getValue() + "'");
				} else {
					setValue.append(", '" + rst.getValue() + "'");
				}
			}

			String strQuery = "Insert INTO " + Sheetname + setKey.toString() + ") VALUES " + setValue.toString() + ")";
			connection.executeUpdate(strQuery);
			connection.close();
		} catch (FilloException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void callMethodByModule(String moduleName, Integer iCount, String region) {
		
		
		columnFlag = true;
		iRegion = region;
		iteration = new HashMap<>();
		for (int i = 1; i <= iCount; i++) {
			result = new HashMap<>();
			status = true;
			switch (moduleName.toLowerCase()) {
			case "customercreation":
				customerCreation(i);
				break;
			case "ddacashaccount":
				createDDACashAccount(i);
				break;
			case "moneymarketaccount":
				createMoneyMarketAccount(i);
				break;	
			case "customerportfolio":
				customerPortFolio( i);
				break;
			case "broker":
				createBroker( i);
				break;
			case "depository":
				createDepository(i);
				break;
			case "fundtransfer":
				fundTransfer( i);
				break;
			case "feesdata":
				feesTestData( i);
				break;
			case "counterparty":
				counterPartyCreation( i);
				break;
			case "nastroaccount":
				createNastroAccount( i);
				break;
			case"aum_account":
				createAUMAccount(i);
				break;
			case"aum_portfolio":
				createAUMPortfolio(i);
				break;
			case "aum_fundtransfer":
				createAUMFundTransfer(i);
			case "equity":
				createEquity(i);;
				break;
			case "equitybuyorder":
				createEquityBuyOrder(i); 
				break;
			case "equitysellorder":
				createEquityBuySellOrder(i);
				break;
			default:
				break;
			}
		}

	}
	
	private static void createHeaders(String name, String[] arg) {
		if (columnFlag) {
			XSSFWorkbook workbook;
			XSSFSheet sheet;
			FileOutputStream out;
			Row row;
			Cell cell;
			File fl = new File(reportfile);
			try {
				FileInputStream input = new FileInputStream(fl);
				workbook = new XSSFWorkbook(input);
				sheet = workbook.createSheet(name);
				row = sheet.createRow(0);
				cell = row.createCell(0);
				sheet.setColumnWidth(0, 5000);
				System.out.println("Scenarioname  created");
				cell.setCellValue("ScenarioName");
				for (int i = 0; i < arg.length; i++) {
					cell = row.createCell(i + 1);
					cell.setCellValue(arg[i]);
					sheet.setColumnWidth(i+1, 5000);
					System.out.println(arg[i] + "created");
					
				}
				
				out = new FileOutputStream(fl);
				workbook.write(out);
				out.close();
				columnFlag = false;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public static void enableSSLSocket() throws NoSuchAlgorithmException, KeyManagementException {
		HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {

			@Override
			public boolean verify(String hostname, SSLSession session) {
				// TODO Auto-generated method stub
				return true;
			}
		});

		SSLContext context = SSLContext.getInstance("TLS");
		context.init(null, new X509TrustManager[] { new X509TrustManager() {
			public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
			}

			public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
			}

			public X509Certificate[] getAcceptedIssuers() {
				return new X509Certificate[0];
			}
		} }, new SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(context.getSocketFactory());
	}

	@Override
	public void run() {
		boolean chFlag = false, usFlag =false;
		RollingFileAppender appender = new RollingFileAppender();
		
		this.createOutputFolder();
		for(Modules lst: moduleList) {
			if(lst.getICHSelect().isSelected()) {
				chFlag = true;
			}
			if(lst.getIUSSelect().isSelected()) {
				usFlag = true;
			}
		}
		if(chFlag) {
			logs.removeAppender(appender);
			this.logFile =reportPath + "/"+ "logFile_CH.log";
			appender.setAppend(true);
			appender.setFile(this.logFile);
			appender.activateOptions();
			PatternLayout layOut = new PatternLayout();
	        layOut.setConversionPattern("%d{yyyy-MM-dd HH:mm:ss} %-5p [%c{1}:%L] - %m%n");
	        appender.setLayout(layOut);
	        logs.addAppender(appender);
			this.createOutputFile("CHOutputData");
			for (Modules lst : moduleList) {
				if (lst.getICHSelect().isSelected()) {
					// this.createsheet(lst.getModuleName());
					int endNumber = Integer.parseInt(lst.getICount());
					callMethodByModule(lst.getModuleName(), endNumber, "CH");
				}
			}
		}
		
		if(usFlag) {
			this.logFile =reportPath + "/"+ "logFile_US.log";
			logs.removeAppender(appender);
			appender.setAppend(true);
			appender.setFile(this.logFile);
			appender.activateOptions();
			PatternLayout layOut = new PatternLayout();
	        layOut.setConversionPattern("%d{yyyy-MM-dd HH:mm:ss} %-5p [%c{1}:%L] - %m%n");
	        appender.setLayout(layOut);
	        logs.addAppender(appender);
			this.createOutputFile("USOutputData");
			for (Modules lst : moduleList) {
				if (lst.getIUSSelect().isSelected()) {
					int endNumber = Integer.parseInt(lst.getICount());
					callMethodByModule(lst.getModuleName(), endNumber, "US");
				} 
			}
		}
			
		JOptionPane.showMessageDialog(null, "Completed", "Information", 1);
	}
	
	
	private void createOutputFolder() {
		SimpleDateFormat formatdate = new SimpleDateFormat("dd-MM-YYYY");
		java.util.Date date = new java.util.Date(); 
		String newDate = formatdate.format(date).toString();
		System.out.println(newDate);
		reportPath = "./reports/"+newDate;
		 File directory = new File(reportPath);
	  		if (!directory.exists()) {
	  			directory.mkdirs();
	  			System.out.println("Output folder created");
	  		}
	  		formatdate = new SimpleDateFormat("HH-mm-ss");
			newDate = formatdate.format(date).toString();
			reportPath = reportPath + "/" + newDate;
			directory = new File(reportPath);
			if (!directory.exists()) {
	  			directory.mkdirs();
	  			logs.info("Output folder created");
	  		}
	}
	
	
	
	
	private void createOutputFile(String fileName) {
		this.fileName = fileName;	
		this.reportfile = reportPath + "/" + this.fileName +".xlsx";
	  	File fl = new File(reportfile);
	  	if (!fl.exists()){	
	  		try {
	  			FileOutputStream out = new FileOutputStream(fl);
	  			XSSFWorkbook workbook = new XSSFWorkbook();
				workbook.write(out);
				logs.info("Output File created");
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	  	}
	}

}
