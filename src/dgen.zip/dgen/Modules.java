package dgen;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.control.CheckBox;

public class Modules {
	private final SimpleStringProperty moduleName;
	private final SimpleStringProperty iCount;
	private CheckBox iCHSelect;
	private CheckBox iUSSelect;
	public Modules(String moduleName, String count, boolean chStatus, boolean usStatus){
		this.moduleName = new SimpleStringProperty(moduleName);
		this.iCount = new SimpleStringProperty(count);
		this.iUSSelect = new CheckBox();
		this.iCHSelect = new CheckBox();
		if(!chStatus) {
			iCHSelect.setDisable(true);
		}
		if(!usStatus) {
			iUSSelect.setDisable(true);
		}
		
		
	}
	
	public String getModuleName() {
		return moduleName.get();
	}
	
	public void setModuleName(String moduleName) {
		this.moduleName.set(moduleName);
	}
	
	public String getICount() {
		return iCount.get();
	}
	
	public void setiCount(String iCount) {
		this.iCount.set(iCount);
	}
	
	public CheckBox getICHSelect() {
		return iCHSelect;
	}
	
	public void setICHSelect(CheckBox select) {
		this.iCHSelect=select;
	}
	
	public CheckBox getIUSSelect() {
		return iUSSelect;
	}
	
	public void setIUSSelect(CheckBox select) {
		this.iUSSelect=select;
	}
	
}
